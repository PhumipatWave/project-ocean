// Superseded by SpawnCatalog.cs
